﻿using System;
using System.Threading;
using CSharpAutomationFramework.Framework.Base;
using CSharpAutomationFramework.Framework.Core;
using OpenQA.Selenium;
using CSharpAutomationFramework.PageObjects.tcfa;

namespace CSharpTestAutomation.PageObjects.tcfa
{
    public class ForgotPasswordPage
    {
        private Reporting reporter;
        private IWebDriver driver;
        private Wrapper wrapper;

        //PageUiObjects
        private readonly String edtLoginId = "id:=txtLoginID";
        private readonly String edtOtp = "id:=txtOTP";
        private readonly String edtNewPassword = "id:=txtNewPwd";
        private readonly String edtReEnterNewPassword = "id:=txtRtypeNewPwd";
        private readonly String btnRequestOtp = "id:=btnRequestOtp";
        private readonly String btnValidate = "id:=btnValidate";
        private readonly String btnSubmit = "id:=btnSubmit";
        private readonly String btnReset = "id:=btnReset";
        private readonly String btnCancel = "id:=btnCancel";

        public ForgotPasswordPage(IWebDriver driver, Reporting reporter)
        {
            this.reporter = reporter;
            this.driver = driver;
            wrapper = new Wrapper(driver, reporter);
        }
        public ForgotPasswordPage EnterLoginIDAndRequestOTP(string loginId)
        {
            wrapper.EnterText(edtLoginId, loginId)
                   .Click(btnRequestOtp)
                   .HandleAlert();
            return this;
        }
        public ForgotPasswordPage EnterOTPAndValidate(string otp)
        {
            wrapper.EnterText(edtOtp, otp)
                   .Click(btnValidate)
                   .HandleAlert();
            return this;
        }
        public ForgotPasswordPage EnterNewPassword(string password)
        {
            wrapper.EnterText(edtNewPassword, password)
                   .EnterText(edtReEnterNewPassword, password);
            return this;
        }
        public LoginPage ClickSubmit()
        {
            wrapper.Click(btnSubmit)
                   .HandleAlert();
            return new LoginPage(driver, reporter);
        }
    }
}
