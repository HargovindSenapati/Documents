﻿using System;
using CSharpAutomationFramework.Framework.Base;
using CSharpAutomationFramework.Framework.Core;
using OpenQA.Selenium;
using CSharpTestAutomation.PageObjects.tcfa;

namespace CSharpTestAutomation.PageObjects.tcfa
{
   public class NewCustomerRegistrationPage : BasePage
    {
        private Reporting reporter;
        private IWebDriver driver;
        private Wrapper wrapper;

        //PageUiObjects
        private readonly String lnkMenu = "id:=lnkLHMenu";
        private readonly String imgExpand = "xpath:=//a[text()='{0}']/../../td/a/img";
        private readonly String edtApplicationNumber = "id:=txtApplicationNo";
        
        public NewCustomerRegistrationPage(IWebDriver driver, Reporting reporter)
        {
            this.reporter = reporter;
            this.driver = driver;
            wrapper = new Wrapper(driver, reporter);
        }
        public NewCustomerRegistrationPage ExpandMenu(String menuName)
        {
            driver.SwitchTo().Frame("header");
            wrapper.Click(lnkMenu);
            driver.SwitchTo().DefaultContent();
            driver.SwitchTo().Frame("contents");
            wrapper.Click(String.Format(imgExpand, menuName));
            return this;
        }

        public NewCustomerRegistrationPage SelectMenuItem(String menuItem)
        {

            wrapper.Click("linktext:=" + menuItem);
            return this;
        }
    }
}
