﻿using System;
using CSharpAutomationFramework.Framework.Base;
using CSharpAutomationFramework.Framework.Core;
using OpenQA.Selenium;
using CSharpTestAutomation.PageObjects.tcfa;

namespace CSharpAutomationFramework.PageObjects.tcfa
{
    public class LoginPage : BasePage
    { 
        private Reporting reporter;
        private IWebDriver driver;
        private Wrapper wrapper;

        //PageUiObjects
        private readonly String edtUserName = "id:=txtFLloginName";
        private readonly String edtLocation = "id:=txtFLlocation";
        private readonly String edtPassword = "id:=txtFLpassword";
        private readonly String rdbtApplicationEntry = "id:=rdbtccnetAppEntry";
        private readonly String btnLogin = "id:=imgbtnFLsubmit";
        private readonly String lnkForgotPassword = "id:=btnResetPwd";
        private readonly String edtApplicationNumber = "id:=txtApplicationNo";

        public LoginPage(IWebDriver driver, Reporting reporter)
        {
            this.reporter = reporter;
            this.driver = driver;
            wrapper = new Wrapper(driver, reporter);
        }


        public LoginPage EnterCredentials(String username, String location, String password)
        {
            wrapper.EnterText(edtUserName,username);
            wrapper.EnterText(edtLocation,location);
            wrapper.EnterText(edtPassword,password);
            wrapper.CheckCheckBox(rdbtApplicationEntry);
            reporter.WriteToTestLevelReport("Enter required details", "All fields should be filled", "All fields filled successfully", "Pass");
            return this;
        }

        public HomePage ClickLogin()
        {
            wrapper.Click(btnLogin);
            return new HomePage(driver, reporter);
        }

        public ForgotPasswordPage ClickForgotPassword()
        {
            wrapper.Click(lnkForgotPassword);
            return new ForgotPasswordPage(driver, reporter);
        }
        
    }
}
