﻿using System;
using System.Threading;
using CSharpAutomationFramework.Framework.Base;
using CSharpAutomationFramework.Framework.Core;
using OpenQA.Selenium;

namespace CSharpAutomationFramework.PageObjects.tcfa
{
    public class HomePage : BasePage
    {
        private Reporting reporter;
        private IWebDriver driver;
        private Wrapper wrapper;

        //PageUiObjects
        private readonly String lnkMenu = "id:=lnkLHMenu";
        private readonly String imgExpand = "xpath:=//a[text()='{0}']/../../td/a/img";
        private readonly String rdSelectAll = "id:=rdfrgselect";
        private readonly String rdRemoveAll = "id:=rdcrgremove";


        public HomePage(IWebDriver driver, Reporting reporter)
        {
            this.reporter = reporter;
            this.driver = driver;
            wrapper = new Wrapper(driver, reporter);
        }
        public HomePage ExpandMenu(String menuName)
        {
            driver.SwitchTo().Frame("header");
            wrapper.Click(lnkMenu);
            driver.SwitchTo().DefaultContent();
            driver.SwitchTo().Frame("contents");
            wrapper.Click(String.Format(imgExpand, menuName));
            return this;
        }

        public HomePage SelectMenuItem(String menuItem)
        {
            
            wrapper.Click("linktext:=" + menuItem);
            return this;
        }

        public HomePage SelectAll()
        {
            driver.SwitchTo().DefaultContent();
            driver.SwitchTo().Frame("main");
            wrapper.Click(rdSelectAll);
            return this;
        }

        public HomePage RemoveAll()
        {
            driver.SwitchTo().DefaultContent();
            driver.SwitchTo().Frame("main");
            wrapper.Click(rdRemoveAll);
            return this;
        }
    }
}

