﻿using System;
using CSharpAutomationFramework.Framework.Core;
using OpenQA.Selenium;

namespace CSharpAutomationFramework.PageObjects.tcfa
{
    public class LaunchApplication
    {
        private Reporting reporter;
        private IWebDriver driver;

        public LaunchApplication(IWebDriver driver, Reporting reporter)
        {
            this.reporter = reporter;
            this.driver = driver;
        }

        public LoginPage launchTcfa(String url)
        {
            driver.Navigate().GoToUrl(url);
            reporter.WriteToTestLevelReport("Navigate to specified URL", "URL: ", "Navigated to URL: ", "Done");
            return new LoginPage(driver, reporter);
        }
    }
}
