﻿using System;
namespace CSharpAutomationFramework.Constants.Tcfa
{
    public static class TcfaDataKeys
    {
        public const string USERNAME = "username";
        public const string LOCATION = "location";
        public const string PASSWORD = "password";
        public const string LOGINID = "loginid";
        public const string OTP = "otp";
        public const string APPLICATIONNUMBER = "7867867867";
    }
}
