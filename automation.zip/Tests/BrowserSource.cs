﻿using System;
namespace CSharpAutomationFramework.Tests
{
    public class BrowserSource
    {
        static string[] Browsers = {
            "chrome"
        };
    }
}
