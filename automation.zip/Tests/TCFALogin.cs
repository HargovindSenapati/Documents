﻿using System;
using CSharpAutomationFramework.Constants.Tcfa;
using CSharpAutomationFramework.Framework.Handlers;
using CSharpAutomationFramework.Framework.Helpers;
using CSharpAutomationFramework.PageObjects.tcfa;
using CSharpAutomationFramework.Tests;
using CSharpAutomationFramework.Tests.Base;
using NUnit.Framework;
using System.Threading;

namespace CSharpTestAutomation.Tests
{
    [TestFixtureSource(typeof(BrowserSource), "Browsers")]
    public class TCFALogin : BaseSeleniumWebTest
    {
        private readonly String configFile = "tcfa.json";
        private readonly String dataFile = "staticdata.json";
        DataHandler dHandler;

        public TCFALogin(String browser)
        {
            this.browser = browser;
            Environment.SetEnvironmentVariable("envName", TestContext.Parameters.Get("env"));
        }

        [OneTimeSetUp]
        new public void BeforeClass()
        {
            SetClassName(this);
            base.BeforeClass();

            dHandler = new DataHandler(configFile, dataFile);
        }

        [SetUp]
        new public void BeforeMethod()
        {
            SetWebDriver();
            base.BeforeMethod();
        }

        [Test]
        public void TestValidateLogin()
        {
            String url = dHandler.GetAppConfig(TcfaConfigKeys.URL).ToString();
            LoginPage loginpage = new LaunchApplication(driver, Reporter)
                .launchTcfa(url);

            String username = dHandler.GetAppData(TcfaDataKeys.USERNAME).ToString();
            String location = dHandler.GetAppData(TcfaDataKeys.LOCATION).ToString();
            String password = dHandler.GetAppData(TcfaDataKeys.PASSWORD).ToString();

            loginpage.EnterCredentials(username,location, password).ClickLogin();
         }

        [Test]

        public void TestForgotPassword()
        {
            String url = dHandler.GetAppConfig(TcfaConfigKeys.URL).ToString();
            LoginPage loginpage = new LaunchApplication(driver, Reporter)
                .launchTcfa(url);

            String loginid = dHandler.GetAppData(TcfaDataKeys.LOGINID).ToString();
            String otp = dHandler.GetAppData(TcfaDataKeys.OTP).ToString();
            loginpage.ClickForgotPassword()
                .EnterLoginIDAndRequestOTP(loginid)
                .EnterOTPAndValidate(otp)
                .EnterNewPassword("testpassword")
                .ClickSubmit();
             }

        [Test]

        public void TestApprovalFlow()
        {
            String url = dHandler.GetAppConfig(TcfaConfigKeys.URL).ToString();
            LoginPage loginpage = new LaunchApplication(driver, Reporter)
                .launchTcfa(url);

            String username = dHandler.GetAppData(TcfaDataKeys.USERNAME).ToString();
            String location = dHandler.GetAppData(TcfaDataKeys.LOCATION).ToString();
            String password = dHandler.GetAppData(TcfaDataKeys.PASSWORD).ToString();
            String applicationnumber = dHandler.GetAppData(TcfaDataKeys.APPLICATIONNUMBER).ToString();


            loginpage.EnterCredentials(username, location, password)
                .ClickLogin()
                .ExpandMenu("Registration")
                .SelectMenuItem("New Customer Registration");
                //.RemoveAll();

            Thread.Sleep(2000);
        }

        public void TestNewCustomerRegistration()
        {
            String url = dHandler.GetAppConfig(TcfaConfigKeys.URL).ToString();
            LoginPage loginpage = new LaunchApplication(driver, Reporter)
                .launchTcfa(url);

            String username = dHandler.GetAppData(TcfaDataKeys.USERNAME).ToString();
            String location = dHandler.GetAppData(TcfaDataKeys.LOCATION).ToString();
            String password = dHandler.GetAppData(TcfaDataKeys.PASSWORD).ToString();

            loginpage.EnterCredentials(username, location, password).ClickLogin();

        }

        [TearDown]
        new public void AfterMethod()
        {
            base.AfterMethod();
        }

        [OneTimeTearDown]
        new public void AfterClass()
        {
            base.AfterClass();
        }
    }
}

