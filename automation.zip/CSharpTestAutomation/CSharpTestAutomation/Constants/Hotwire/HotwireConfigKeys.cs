﻿using System;
namespace CSharpAutomationFramework.Constants.Hotwire
{
    public static class HotwireConfigKeys
    {
        public const String URL = "url";
    }
}
