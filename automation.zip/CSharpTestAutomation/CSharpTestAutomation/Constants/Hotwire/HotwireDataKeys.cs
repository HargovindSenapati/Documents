﻿using System;
namespace CSharpAutomationFramework.Constants.Hotwire
{
    public static class HotwireDataKeys
    {
        public const string FROM_CITY = "fromCity";
        public const string TO_CITY = "toCity";
    }
}
