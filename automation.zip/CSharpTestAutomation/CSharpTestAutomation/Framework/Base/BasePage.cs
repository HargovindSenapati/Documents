﻿using System;
namespace CSharpAutomationFramework.Framework.Base
{
    public class BasePage
    {
        protected BasePage()
        {
        }
    }
}