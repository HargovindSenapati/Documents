﻿using System;
using CSharpAutomationFramework.Framework.Base;
using CSharpAutomationFramework.Framework.Core;
using OpenQA.Selenium;

namespace CSharpTestAutomation.PageObjects.Tcfa
{
    public class LocChequeDepositionReportPage : BasePage
    {
        //PageUiObjects
        readonly String lstPIFNo = "id:=ddlPIFpinno";
        readonly String edtFromDate = "id:=txtPIFfromDate";
        readonly String edtToDate = "id:=txtPIFtoDate";
        readonly String btnSubmit = "id:=cmdPIFsubmit";
        readonly String btnReprint = "id:=cmdPIFreprint";
        readonly String imgFromDate = "id:=ImgFromdate1";
        readonly String imgToDate = "id:=ImgFromdate2";


        public LocChequeDepositionReportPage(IWebDriver driver, Reporting reporter) : base(driver, reporter)
        {
            wrapper.SwitchToDefaultContent()
           .SwitchToFrameWithName("main");
        }
        public LocChequeDepositionReportPage EnterReportDates(String fromDate, String toDate)
        {
            //wrapper.EnterText(edtFromDate, fromDate)
            //     .EnterText(edtToDate, toDate);

            wrapper.Click(imgFromDate)
                   .SwitchToFrameWithName("frameDatePicker")
                   .Click("xpath:=//div[@id='divDatePickerBody']//td[text()='1']")
                   .SwitchToDefaultContent()
                   .SwitchToFrameWithName("main")
                   .Click(imgToDate)
                   .SwitchToFrameWithName("frameDatePicker")
                   .Click("xpath:=//div[@id='divDatePickerBody']//td[text()='28']")
                   .SwitchToDefaultContent()
                   .SwitchToFrameWithName("main");

            return this;
        }

        public LocChequeDepositionReportPage Submit() 
        {
            wrapper.Click(btnSubmit);
            return this;
        }

        public LocChequeDepositionReportPage SelectPIFNo(String pifNo)
        {
            wrapper.SelectOptionFromList(lstPIFNo, pifNo);
            return this;
        }

        public LocChequeDepositionReportPage Reprint()
        {
            wrapper.Click(btnReprint);
            return this;
        }
    }
}
