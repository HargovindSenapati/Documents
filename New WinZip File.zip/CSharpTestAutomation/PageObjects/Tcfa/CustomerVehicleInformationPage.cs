﻿using System;
using CSharpAutomationFramework.Framework.Base;
using CSharpAutomationFramework.Framework.Core;
using CSharpAutomationFramework.Framework.Helpers;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Interactions;

namespace CSharpAutomationFramework.PageObjects.Tcfa
{
    public class CustomerVehicleInformationPage : BasePage
    {
        //Customer Enrollment Objects
        readonly String edtDesignation = "id:=ddlEDBDesignation";
        readonly String edtName = "id:=txtEDBName";
        readonly String edtMobileNumber = "id:=txtEDBContactNo";

        //Dispatch of Card Details
        readonly String radTCC = "id:=RbtnDispatchCardTCC";
        readonly String btnSave = "id:=BtnSaveNExit";

        readonly String btnAttachments = "id:=BtnVehicleEntryattach";
        readonly String btnVehicleEntry = "id:=btnVehicleEntry";

        public CustomerVehicleInformationPage(IWebDriver driver, Reporting reporter) : base(driver, reporter)
        {
            wrapper.SwitchToDefaultContent()
            .SwitchToFrameWithName("main");
        }

        public VehicleEntryPage ClickVehicleEntry() {
            wrapper.Click(btnVehicleEntry);
            return new VehicleEntryPage(driver, reporter);
        }

        public CustomerVehicleInformationPage EnterCustomerEnrollmentDetails(String designation) 
        {
            wrapper.SelectOptionFromList(edtDesignation, designation);
            //Thread.Sleep(5000);
            
            //Actions acts = new Actions(driver);
            //acts.MoveToElement(driver.FindElement(By.Id("txtEDBName")))
            //        .Click()
            //        .SendKeys("t")
            //        .Build()
            //        .Perform();
            //Thread.Sleep(5000);
            //acts.MoveToElement(driver.FindElement(By.Id("txtEDBContactNo")))
            //    .Click()
            //    .SendKeys("9")
            //    .SendKeys("9")
            //    .SendKeys("9")
            //    .SendKeys("9")
            //    .SendKeys("9")
            //    .SendKeys("9")
            //    .SendKeys("9")
            //    .SendKeys("9")
            //    .SendKeys("9")
            //    .SendKeys("9")
            //    .Build()
            //    .Perform();


            wrapper.Click(edtName);
            wrapper.EnterText(edtName, "SENAPATI");
            wrapper.Click(edtMobileNumber);
            wrapper.EnterText(edtMobileNumber, Generic.RandomString(Generic.RandomStringType.Numeric, 10));
            //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            //js.ExecuteScript("document.getElementById('txtEDBName').onkeypress();");
            //js.ExecuteScript("document.getElementById('txtEDBContactNo').onkeypress();");
            return this;
        }

        public AttachmentsPage ClickAttachments()
        {
            wrapper.Click(btnAttachments);
            return new AttachmentsPage(driver, reporter);
        }

        public CustomerVehicleInformationPage ClickSave()
        {
            Thread.Sleep(5000);
            wrapper.Click(btnSave);
            wrapper.AcceptAlert();
            return this;
        }
        public CustomerVehicleInformationPage AcceptAlert()
        {
            wrapper.AcceptAlert();
            return this;
        }
    }
}
