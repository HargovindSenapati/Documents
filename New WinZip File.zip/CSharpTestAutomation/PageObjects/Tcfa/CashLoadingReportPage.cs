﻿using System;
using CSharpAutomationFramework.Framework.Base;
using CSharpAutomationFramework.Framework.Core;
using OpenQA.Selenium;

using static CSharpAutomationFramework.Framework.Helpers.Generic;

namespace CSharpTestAutomation.PageObjects.Tcfa
{
    public class CashLoadingReportPage : BasePage
    {
        //PageUiObjects
        readonly String txtCarrierId = "id:=txtCLcarrierId";
        readonly String lstCustomerId = "id:=ddlCLcustomerid";
        readonly String lstLocationId = "id:=ddlCLlocation";
        readonly String lstPayment = "id:=ddlCLpayID";
        readonly String txtFromDate = "id:=txtCASfromDate";
        readonly String txtToDate = "id:=txtCAStoDate";
        readonly String btnCheckCarrier = "id:=cmdFCRsearchcarrierId";
        readonly String btnSearch = "id:=btnsearch";
        readonly String btnExportToExcel = "id:=btnexportexcel";
        readonly String lnkPrint = "linktext:=Print";

        public CashLoadingReportPage(IWebDriver driver, Reporting reporter) : base(driver, reporter)
        {
            wrapper.SwitchToDefaultContent()
           .SwitchToFrameWithName("main");
        }

        public CashLoadingReportPage CheckCarrier(String carrierid)
        {
            wrapper.EnterText(txtCarrierId, carrierid)
                   .Click(btnCheckCarrier);
            return this;
        }

        public CashLoadingReportPage EnterSearchDetails(String customerId, String location, String payment, String fromDate, String toDate)
        {
            wrapper.SelectOptionFromList(lstCustomerId, customerId)
                   .SelectOptionFromList(lstLocationId, location)
                   .SelectOptionFromList(lstPayment, payment)
                   .EnterText(txtFromDate, fromDate)
                   .EnterText(txtToDate, toDate);
            return this;
        }

        public CashLoadingReportPage Search()
        {
            wrapper.Click(btnSearch);
            return this;
        }

        public CashLoadingReportPage ExportToExcel()
        {
            wrapper.Click(btnExportToExcel);
            return this;
        }

        public CashLoadingReportPage Print()
        {
            wrapper.Click(lnkPrint);
            return this;
        }
    }
}
