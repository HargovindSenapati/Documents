﻿using System;
using CSharpAutomationFramework.Framework.Base;
using CSharpAutomationFramework.Framework.Core;
using OpenQA.Selenium;

namespace CSharpTestAutomation.PageObjects.Tcfa
{
    public class LocalCollectionReportPage : BasePage
    {

        //PageUiObjects
        readonly String lstSource = "id:=ddlMCAsource";
        readonly String lstMOP = "id:=ddlMCAtype";
        readonly String lstType = "id:=ddlMCAType1";
        readonly String edtFromDate = "id:=txtMCAfromDate";
        readonly String edtToDate = "id:=txtMCAtoDate";
        readonly String btnSubmit = "id:=cmdMCAsearch";
        readonly String btnExportToExcel = "id:=CmdExportToExcel";
        readonly String btnReset = "id:=cmdMCAreset";

        public LocalCollectionReportPage(IWebDriver driver, Reporting reporter) : base(driver, reporter)
        {
            wrapper.SwitchToDefaultContent()
           .SwitchToFrameWithName("main");
        }
        public LocalCollectionReportPage EnterSearchCriteria(String source, String mop, String type, String fromDate, String toDate)
        {
            wrapper.SelectOptionFromList(lstSource,source)
                   .SelectOptionFromList(lstMOP, mop)
                   .SelectOptionFromList(lstType, type)
                   .EnterText(edtFromDate, fromDate)
                   .EnterText(edtToDate, toDate);
            
            return this;
        }

        public LocalCollectionReportPage Submit()
        {
            wrapper.Click(btnSubmit);
            return this;
        }

        public LocalCollectionReportPage ExportToExcel()
        {
            wrapper.Click(btnExportToExcel);
            return this;
        }

        public LocalCollectionReportPage Reset()
        {
            wrapper.Click(btnReset);
            return this;
        }

    }
}
