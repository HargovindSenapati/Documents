﻿using System;
namespace CSharpAutomationFramework.Constants.Tcfa
{
    public static class TcfaConfigKeys
    {
        public const String URL = "url";
    }
}
