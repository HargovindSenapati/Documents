﻿using System;
namespace CSharpAutomationFramework.Constants.Tcfa
{
    public static class TcfaDataKeys
    {
        public const String USERNAME = "username";
        public const String PASSWORD = "password";
        public const String LOCATION = "location";

        public const String OTP = "otp";
        public const String LOGINID = "loginid";

        public const String STATE = "state";
        public const String DISTRICT = "district";
        public const String CITY = "city";

        public const String ROUTE_TYPE = "routetype";
        public const String ROUTE_FROM = "routefrom";
        public const String ROUTE_TO = "routeto";

        public const String TYPE_OF_CARD = "typeofcard";
        public const String DESIGNATION = "designation";

        public const String CAPTIVE_CARD = "captivecard";

        public const String APP_FORM_PATH = "appformpath";
        public const String IDENTITY_PROOF_PATH = "identityproofpath";
        public const String ADD_PROOF_PATH = "addproofpath";

        public const String MCA_SOURCE = "mcasource";
        public const String MCA_MOP = "mcamop";
        public const String MCA_TYPE = "mcatype";
        public const String MCA_FROMDATE = "mcafromdate";
        public const String MCA_TODATE = "mcatodate";

        public const String PIFNO = "pifno";
        public const String PIF_FROMDATE = "piffromdate";
        public const String PIF_TODATE = "piftodate";

        public const String CL_CARRIER_ID = "clcarrierid";
        public const String CL_CUSTOMER_ID = "clcustomerid";
        public const String CL_LOCATION_ID = "cllocationid";
        public const String CL_PAYMENT = "clpayment";
        public const String CL_FROMDATE = "clfromdate";
        public const String CL_TODATE = "cltodate";


    }
}
