﻿using System;
using CSharpAutomationFramework.Constants.Tcfa;
using CSharpAutomationFramework.Framework.Handlers;
using CSharpAutomationFramework.PageObjects.Tcfa;
using CSharpAutomationFramework.Tests;
using CSharpAutomationFramework.Tests.Base;
using static CSharpAutomationFramework.Framework.Helpers.Generic;
using NUnit.Framework;
using CSharpTestAutomation.PageObjects.Tcfa;
using System.Threading;

namespace CSharpTestAutomation.Tests
{
    [TestFixtureSource(typeof(BrowserSource), "Browsers")]
    public class TCFAReports : BaseSeleniumWebTest 
    {
        private readonly String configFile = "tcfa.json";
        private readonly String dataFile = "staticdata.json";
        DataHandler dHandler;

        public TCFAReports(String browser)
        {
            this.browser = browser;
            Environment.SetEnvironmentVariable("envName", TestContext.Parameters.Get("env"));
        }

        [OneTimeSetUp]
        new public void BeforeClass()
        {
            SetClassName(this);
            base.BeforeClass();

            dHandler = new DataHandler(configFile, dataFile);
        }

        [SetUp]
        new public void BeforeMethod()
        {
            SetWebDriver();
            base.BeforeMethod();

            LoginPage loginpage = new LaunchApplication(driver, Reporter)
                .launchTcfa(dHandler.GetAppConfig(TcfaConfigKeys.URL));

            loginpage.EnterCredentials(dHandler.GetAppData(TcfaDataKeys.USERNAME),
                                       dHandler.GetAppData(TcfaDataKeys.LOCATION),
                                       dHandler.GetAppData(TcfaDataKeys.PASSWORD))
                     .ClickLogin();
        }

        [Test]
        public void TestLocalCollectionReport()
        {
            HomePage homePage = new HomePage(driver, Reporter);
            homePage.ExpandMenu("Reports")
                    .SelectMenuItem("Location Collection Report");

            LocalCollectionReportPage localCollectionReportPage = new LocalCollectionReportPage(driver, Reporter);
            localCollectionReportPage.EnterSearchCriteria(dHandler.GetAppData(TcfaDataKeys.MCA_SOURCE),
                                                          dHandler.GetAppData(TcfaDataKeys.MCA_MOP),
                                                          dHandler.GetAppData(TcfaDataKeys.MCA_TYPE),
                                                          dHandler.GetAppData(TcfaDataKeys.MCA_FROMDATE),
                                                          dHandler.GetAppData(TcfaDataKeys.MCA_TODATE))
                                     .Submit()
                                     .ExportToExcel();
            Thread.Sleep(5000);
        }

        [Test]
        public void TestLocationChequeDepositionReport()
        {
            HomePage homePage = new HomePage(driver, Reporter);
            homePage.ExpandMenu("Reports")
                    .SelectMenuItem("Location Cheque Deposition Report");

            LocChequeDepositionReportPage locChequeDepositionReportPage = new LocChequeDepositionReportPage(driver, Reporter);
            locChequeDepositionReportPage.EnterReportDates(dHandler.GetAppData(TcfaDataKeys.PIF_FROMDATE),
                                                           dHandler.GetAppData(TcfaDataKeys.PIF_TODATE))
                                         .Submit()
                                         .SelectPIFNo(dHandler.GetAppData(TcfaDataKeys.PIFNO))
                                         .Reprint();
            Thread.Sleep(5000);
        }

        [Test]
        public void TestCashLoadingReport()
        {
            HomePage homePage = new HomePage(driver, Reporter);
            homePage.ExpandMenu("Reports")
                    .SelectMenuItem("Reprint Receipt (Cash Loading)");

            CashLoadingReportPage cashLoadingReportPage = new CashLoadingReportPage(driver, Reporter);
            cashLoadingReportPage.CheckCarrier(dHandler.GetAppData(TcfaDataKeys.CL_CARRIER_ID))
                                 .EnterSearchDetails(dHandler.GetAppData(TcfaDataKeys.CL_CUSTOMER_ID),
                                                     dHandler.GetAppData(TcfaDataKeys.CL_LOCATION_ID),
                                                     dHandler.GetAppData(TcfaDataKeys.CL_PAYMENT),
                                                     dHandler.GetAppData(TcfaDataKeys.CL_FROMDATE),
                                                     dHandler.GetAppData(TcfaDataKeys.CL_TODATE))
                                 .Search()
                                 .Print()
                                 .ExportToExcel();
            Thread.Sleep(5000);
        }


        [TearDown]
        new public void AfterMethod()
        {
            base.AfterMethod();
        }

        [OneTimeTearDown]
        new public void AfterClass()
        {
            base.AfterClass();
        }

    }
}
